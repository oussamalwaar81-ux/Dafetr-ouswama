دفتر Droguerie Oussama - Android wrapper
========================================

المشروع يحافظ على ملفات HTML/CSS/JavaScript الأصلية كما هي، ويعرضها داخل Android WebView.
لا يوجد تغيير مقصود على تصميم التطبيق أو وظائفه.

لبناء APK:
1. افتح المشروع في Android Studio (اختيار Open).
2. انتظر Gradle Sync.
3. من Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
4. ستجد الملف عادة في app/build/outputs/apk/debug/app-debug.apk

بديل البناء عبر GitHub:
1. ارفع محتويات هذا المشروع إلى مستودع GitHub.
2. افتح Actions ثم Build Android APK ثم Run workflow.
3. نزّل Artifact باسم Dafter-Droguerie-Oussama-APK بعد انتهاء البناء.

ملاحظة: أول تشغيل يحتاج اتصالاً بالإنترنت لتحميل خط Google Fonts؛ بقية ملفات التطبيق محلية.
بيانات الكراءات محفوظة محلياً داخل بيانات التطبيق على الهاتف. لا تحذف بيانات التطبيق أو تزل التطبيق قبل تصدير/حفظ نسخة احتياطية من بياناتك إن كان التطبيق يوفر ذلك.
