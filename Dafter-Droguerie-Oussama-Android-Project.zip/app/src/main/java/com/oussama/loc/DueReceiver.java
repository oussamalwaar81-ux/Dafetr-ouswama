package com.oussama.loc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DueReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        DueChecker.check(context);
    }
}
