package com.oussama.loc;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Posts a notification when an item is late, or when it is due within a few hours. */
final class DueChecker {
    static final String CHANNEL = "due";

    private DueChecker() {
    }

    static void ensureChannel(Context c) {
        NotificationChannel ch = new NotificationChannel(CHANNEL, "تذكير الرجوع", NotificationManager.IMPORTANCE_HIGH);
        c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    /** Checks every 30 minutes, even when the app is closed. */
    static void schedule(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, new Intent(c, DueReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60000L,
                AlarmManager.INTERVAL_HALF_HOUR, pi);
    }

    static void check(Context c) {
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (!nm.areNotificationsEnabled()) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 33
                    && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            SharedPreferences sp = c.getSharedPreferences("loc", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("due", "[]"));
            long now = System.currentTimeMillis();
            String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(now));

            Set<String> old = sp.getStringSet("notified", new HashSet<String>());
            Set<String> done = new HashSet<String>();
            for (String k : old) {
                if (k.endsWith(day)) {
                    done.add(k);
                }
            }

            ensureChannel(c);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                long dueMs = o.getLong("dueMs");
                long dayStart = o.optLong("dayStart", 0L);
                boolean timed = o.optBoolean("timed", false);
                String st = null;
                if (now > dueMs) {
                    st = "late";
                } else if (timed ? (dueMs - now <= 4L * 3600000L) : (now >= dayStart)) {
                    st = "soon";
                }
                if (st == null) {
                    continue;
                }
                String key = o.getString("id") + ":" + st + ":" + day;
                if (done.contains(key)) {
                    continue;
                }
                done.add(key);
                String title = st.equals("late") ? "فات وقت الرجوع" : "قريب يرجع";
                String when = "";
                if (st.equals("soon")) {
                    when = timed ? " · على " + o.optString("time") : " · اليوم";
                }
                post(c, nm, key.hashCode(), title, o.optString("item") + " · " + o.optString("renter") + when);
            }
            sp.edit().putStringSet("notified", done).apply();
        } catch (Exception e) {
            // bad data or notifications unavailable: try again at the next check
        }
    }

    private static void post(Context c, NotificationManager nm, int id, String title, String text) {
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(id, n);
    }
}
