package com.oussama.loc;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_FILE = 1001;
    private static final int REQ_CAMERA = 1002;
    private static final int REQ_NOTIF = 1003;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private SdkCache sdkCache;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int roof = Color.rgb(51, 54, 56);
        getWindow().setStatusBarColor(roof);
        getWindow().setNavigationBarColor(roof);

        sdkCache = new SdkCache(getFilesDir());

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(roof);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243, 245, 248));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new Bridge(), "AndroidApp");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) {
                    return serveAsset(u);
                }
                String path = u.getPath();
                if ("www.gstatic.com".equals(u.getHost()) && path != null
                        && path.startsWith("/firebasejs/") && "GET".equals(request.getMethod())) {
                    return sdkCache.get(u.toString());
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) {
                    return false;
                }
                String scheme = u.getScheme();
                try {
                    if ("tel".equals(scheme)) {
                        startActivity(new Intent(Intent.ACTION_DIAL, u));
                    } else if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)) {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    }
                } catch (Exception e) {
                    // no app can handle this link
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                }
                fileCallback = callback;
                try {
                    if (params.isCaptureEnabled()) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "oussama_" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/OussamaLoc");
                        cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        startActivityForResult(camera, REQ_CAMERA);
                    } else {
                        startActivityForResult(params.createIntent(), REQ_FILE);
                    }
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        DueChecker.ensureChannel(this);
        DueChecker.schedule(this);
        webView.loadUrl("https://" + HOST + "/index.html");
    }

    private WebResourceResponse serveAsset(Uri u) {
        String p = u.getPath();
        if (p == null || p.equals("/")) {
            p = "/index.html";
        }
        try {
            InputStream in = getAssets().open("www" + p);
            return new WebResourceResponse(mime(p), isText(p) ? "UTF-8" : null, in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                    new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
        }
    }

    private static boolean isText(String p) {
        return p.endsWith(".html") || p.endsWith(".js") || p.endsWith(".css") || p.endsWith(".json")
                || p.endsWith(".webmanifest") || p.endsWith(".svg");
    }

    private static String mime(String p) {
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".webmanifest")) return "application/manifest+json";
        return "application/octet-stream";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAMERA) {
            if (fileCallback != null) {
                if (resultCode == RESULT_OK && cameraUri != null) {
                    fileCallback.onReceiveValue(new Uri[]{cameraUri});
                } else {
                    fileCallback.onReceiveValue(null);
                    if (cameraUri != null) {
                        try {
                            getContentResolver().delete(cameraUri, null, null);
                        } catch (Exception e) {
                            // ignore
                        }
                    }
                }
                fileCallback = null;
            }
            cameraUri = null;
        } else if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF && webView != null) {
            DueChecker.check(this);
            webView.post(() -> webView.evaluateJavascript("window.__notifChanged&&window.__notifChanged()", null));
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /** Functions the web page can call as window.AndroidApp.*  */
    private class Bridge {
        @JavascriptInterface
        public void setDue(String json) {
            getSharedPreferences("loc", MODE_PRIVATE).edit().putString("due", json).apply();
            DueChecker.check(MainActivity.this);
        }

        @JavascriptInterface
        public String notifState() {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                SharedPreferences sp = getSharedPreferences("loc", MODE_PRIVATE);
                return sp.getBoolean("asked", false) ? "denied" : "default";
            }
            NotificationManager nm = getSystemService(NotificationManager.class);
            return nm.areNotificationsEnabled() ? "granted" : "denied";
        }

        @JavascriptInterface
        public void requestNotifications() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33) {
                    getSharedPreferences("loc", MODE_PRIVATE).edit().putBoolean("asked", true).apply();
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                }
            });
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(i);
                } catch (Exception e) {
                    // settings screen unavailable
                }
            });
        }

        @JavascriptInterface
        public void addCalendar(String title, double beginMs, String desc) {
            final long begin = (long) beginMs;
            final String t = title;
            final String d = desc;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_INSERT);
                    i.setData(CalendarContract.Events.CONTENT_URI);
                    i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin);
                    i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 30L * 60L * 1000L);
                    i.putExtra(CalendarContract.Events.TITLE, t);
                    i.putExtra(CalendarContract.Events.DESCRIPTION, d);
                    startActivity(i);
                } catch (Exception e) {
                    // no calendar app installed
                }
            });
        }
    }
}
