package com.oussama.loc;

import android.webkit.WebResourceResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

/**
 * Keeps the Firebase scripts (versioned, never change) on the phone, so the app opens without internet
 * after the first launch.
 */
final class SdkCache {
    private final File dir;

    SdkCache(File filesDir) {
        dir = new File(filesDir, "sdk");
        dir.mkdirs();
    }

    synchronized WebResourceResponse get(String url) {
        try {
            File f = new File(dir, name(url));
            if (!f.exists()) {
                File tmp = new File(dir, f.getName() + ".tmp");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                if (c.getResponseCode() != 200) {
                    return null;
                }
                InputStream in = c.getInputStream();
                FileOutputStream out = new FileOutputStream(tmp);
                try {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                    }
                } finally {
                    out.close();
                    in.close();
                }
                if (!tmp.renameTo(f)) {
                    return null;
                }
            }
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse("application/javascript", "UTF-8", 200, "OK", headers, new FileInputStream(f));
        } catch (Exception e) {
            return null;
        }
    }

    private static String name(String url) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] d = md.digest(url.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
