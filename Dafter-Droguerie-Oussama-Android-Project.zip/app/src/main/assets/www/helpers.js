// Pure date, money and due-time helpers. No DOM access, so they can be tested alone.
export const pad = n => String(n).padStart(2, '0');
export const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const utc = s => { const p = s.split('-').map(Number); return Date.UTC(p[0], p[1] - 1, p[2]); };
export const diffDays = (a, b) => Math.round((utc(b) - utc(a)) / 864e5);
export const addDays = (s, n) => {
  const t = new Date(utc(s) + n * 864e5);
  return t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate());
};
export const dayWord = n => n === 1 ? 'نهار واحد' : n === 2 ? 'يومين' : n <= 10 ? n + ' أيام' : n + ' يوم';
export const hourWord = n => n <= 1 ? 'ساعة' : n === 2 ? 'ساعتين' : n <= 10 ? n + ' ساعات' : n + ' ساعة';
export const money = n => (Math.round(n * 100) / 100).toLocaleString('en-US') + ' درهم';
export const normName = s => String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' ');
export const hasDays = r => r.days !== null && r.days !== undefined && r.days !== '';

// When is the item due? days = 0 means the same day. dueTime ("HH:MM") is optional.
export function dueInfo(r) {
  if (!hasDays(r)) return null;
  const date = addDays(r.start, Number(r.days));
  const timed = !!r.dueTime;
  const [y, m, d] = date.split('-').map(Number);
  const [hh, mm] = (timed ? r.dueTime : '23:59').split(':').map(Number);
  return {
    date, timed,
    ms: new Date(y, m - 1, d, hh, mm, 0).getTime(),
    dayStart: new Date(y, m - 1, d, 0, 0, 0).getTime()
  };
}

export function calc(r, now = new Date()) {
  const today = ymd(now), returned = r.status === 'returned';
  const end = returned ? (r.returnDate || today) : today;
  const days = Math.max(1, diffDays(r.start, end));
  const total = days * Number(r.price || 0);
  const di = returned ? null : dueInfo(r);
  let state = 'open', label = 'بلا مدة';
  if (di) {
    const nowMs = now.getTime();
    if (di.timed ? nowMs > di.ms : today > di.date) {
      state = 'late';
      if (di.timed && nowMs - di.ms < 864e5) label = 'فات ب' + hourWord(Math.max(1, Math.floor((nowMs - di.ms) / 36e5)));
      else label = 'فات ب' + dayWord(Math.max(1, di.timed ? Math.floor((nowMs - di.ms) / 864e5) : diffDays(di.date, today)));
    } else if (di.timed && di.ms - nowMs <= 4 * 36e5) {
      state = 'hours';
      label = 'باقي ' + hourWord(Math.max(1, Math.ceil((di.ms - nowMs) / 36e5))) + ' (' + r.dueTime + ')';
    } else if (di.date === today) {
      state = 'today'; label = 'ترجع اليوم' + (di.timed ? ' على ' + r.dueTime : '');
    } else if (di.date === addDays(today, 1)) {
      state = 'tomorrow'; label = 'ترجع غدا' + (di.timed ? ' على ' + r.dueTime : '');
    } else {
      state = 'ok'; label = 'باقي ' + dayWord(diffDays(today, di.date));
    }
  }
  return { days, total, due: di, state, label };
}

const icsEsc = s => String(s == null ? '' : s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
export function buildIcs(r, di, stamp) {
  const d = di.date.replace(/-/g, '');
  const t = di.timed ? r.dueTime.replace(':', '') + '00' : '090000';
  const desc = ['الأداة: ' + r.item, 'الكليان: ' + r.renter]
    .concat(r.phone ? ['الهاتف: ' + r.phone] : [], r.guarantee ? ['الضمانة: ' + r.guarantee] : [], ['تمن النهار: ' + r.price + ' درهم']).join('\n');
  const first = di.timed ? '-PT3H' : '-PT15H';
  return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Oussama Loc//AR', 'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT', 'UID:' + r.id + '@oussama-loc', 'DTSTAMP:' + stamp, 'DTSTART:' + d + 'T' + t, 'DURATION:PT30M',
    'SUMMARY:' + icsEsc('رجوع ' + r.item + ' - ' + r.renter), 'DESCRIPTION:' + icsEsc(desc),
    'BEGIN:VALARM', 'TRIGGER:' + first, 'ACTION:DISPLAY', 'DESCRIPTION:' + icsEsc('قريب يرجع ' + r.item), 'END:VALARM',
    'BEGIN:VALARM', 'TRIGGER:PT0S', 'ACTION:DISPLAY', 'DESCRIPTION:' + icsEsc('وقت رجوع ' + r.item), 'END:VALARM',
    'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
}
