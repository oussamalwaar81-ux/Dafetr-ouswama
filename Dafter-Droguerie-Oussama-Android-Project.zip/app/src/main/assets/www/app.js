import { ymd, diffDays, addDays, dayWord, money, normName, calc, dueInfo, hasDays, buildIcs } from './helpers.js';
import { firebaseConfig } from './firebase-config.js';

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// Set by the Android wrapper (native notifications, calendar, camera); null in a normal browser.
const NATIVE = window.AndroidApp || null;
const FB_V = '10.14.1', LS_KEY = 'dafter-lkira-v2', KINDS = ['rentals', 'equipment', 'shortages'];

let store = null, unsubs = [], fb = null, user = null;
const data = { rentals: [], equipment: [], shortages: [] };
const got = { rentals: false, equipment: false, shortages: false };
let loaded = false, timedOut = false, loadTimer = null;
let tab = 'active', returning = null, retDate = '', lastDay = '', toastTimer = null;
let confirmDel = null, confirmDelEq = null, confirmDelSh = null, savedId = null;
let askedOnce = false;
let formEquipId = null, editingEquip = null, editingSh = null, deferredInstall = null;

const todayStr = () => ymd(new Date());
const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const findEquip = name => { const n = normName(name); return n ? data.equipment.find(e => normName(e.name) === n) || null : null; };
const equipOf = r => (r.itemId && data.equipment.find(e => e.id === r.itemId)) || findEquip(r.item);
const activeRentals = () => data.rentals.filter(r => r.status !== 'returned');
const rentedBy = eq => activeRentals().find(r => r.itemId === eq.id || normName(r.item) === normName(eq.name)) || null;

function toast(msg) {
  $('toastMsg').textContent = msg; $('toast').hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3500);
}
function fmtDate(s, today) {
  try {
    const o = { day: 'numeric', month: 'long', timeZone: 'UTC' };
    if (today && s.slice(0, 4) !== today.slice(0, 4)) o.year = 'numeric';
    return new Intl.DateTimeFormat('ar-MA-u-nu-latn', o).format(new Date(Date.UTC(...s.split('-').map((x, i) => i === 1 ? +x - 1 : +x))));
  } catch (e) { return s; }
}
function headerDate() {
  try { return new Intl.DateTimeFormat('ar-MA-u-nu-latn', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date()); }
  catch (e) { return todayStr(); }
}

/* ---------- tiny IndexedDB key-value (shared with the service worker) ---------- */
function idb() {
  return new Promise((res, rej) => {
    const q = indexedDB.open('oussama-loc', 1);
    q.onupgradeneeded = () => q.result.createObjectStore('kv');
    q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error);
  });
}
async function kvSet(k, v) {
  try {
    const db = await idb();
    return await new Promise(r => { const tx = db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = () => r(); tx.onerror = () => r(); });
  } catch (e) { /* storage blocked */ }
}

/* ---------- data stores ---------- */
function localStore() {
  const d = { rentals: [], equipment: [], shortages: [] };
  const subs = { rentals: [], equipment: [], shortages: [] };
  try {
    const v = JSON.parse(localStorage.getItem(LS_KEY) || 'null');
    if (v) KINDS.forEach(k => { if (Array.isArray(v[k])) d[k] = v[k]; });
  } catch (e) { /* ignore */ }
  const save = () => { try { localStorage.setItem(LS_KEY, JSON.stringify(d)); } catch (e) { toast('المساحة ممتلية، ما تحفظاتش'); } };
  const emit = k => subs[k].forEach(f => f(d[k].slice()));
  return {
    mode: 'local',
    subscribe(k, cb) { subs[k].push(cb); cb(d[k].slice()); return () => { subs[k] = subs[k].filter(x => x !== cb); }; },
    create(k, o) { d[k].push(o); save(); emit(k); return Promise.resolve(); },
    patch(k, id, p) { d[k] = d[k].map(x => x.id === id ? Object.assign({}, x, p) : x); save(); emit(k); return Promise.resolve(); },
    remove(k, id) { d[k] = d[k].filter(x => x.id !== id); save(); emit(k); return Promise.resolve(); },
    dump: () => d
  };
}
function fbStore(u) {
  const ref = (k, id) => fb.doc(fb.db, 'users', u.uid, k, id);
  const fail = () => toast('ما تسجلاتش، عاود جرب');
  // Writes are not awaited: offline they stay queued and sync when the connection returns.
  return {
    mode: 'firebase',
    subscribe(k, cb, onErr) {
      return fb.onSnapshot(fb.collection(fb.db, 'users', u.uid, k), s => cb(s.docs.map(x => Object.assign({}, x.data(), { id: x.id }))), onErr);
    },
    create(k, o) { fb.setDoc(ref(k, o.id), o).catch(fail); return Promise.resolve(); },
    patch(k, id, p) { fb.updateDoc(ref(k, id), p).catch(fail); return Promise.resolve(); },
    remove(k, id) { fb.deleteDoc(ref(k, id)).catch(fail); return Promise.resolve(); }
  };
}

/* ---------- photos: camera or gallery, shrunk before saving ---------- */
function readPhoto(file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const max = 480, s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const w = Math.max(1, Math.round(img.naturalWidth * s)), h = Math.max(1, Math.round(img.naturalHeight * s));
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      c.getContext('2d').drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.7));
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
    img.src = url;
  });
}
function makePhoto(p) {
  const row = document.querySelector('[data-photo="' + p + '"]');
  row.innerHTML = '<img class="prev" id="' + p + '-prev" alt="" hidden>' +
    '<label class="btn small primary" for="' + p + '-cam">صوّر</label>' +
    '<label class="btn small" for="' + p + '-gal">من الصور</label>' +
    '<button type="button" class="btn small warn" id="' + p + '-rm" hidden>حيد الصورة</button>' +
    '<input type="file" class="sr" id="' + p + '-cam" accept="image/*" capture="environment">' +
    '<input type="file" class="sr" id="' + p + '-gal" accept="image/*">';
  const prev = $(p + '-prev'), rm = $(p + '-rm'), cam = $(p + '-cam'), gal = $(p + '-gal');
  let val = '';
  const paint = () => { prev.hidden = !val; rm.hidden = !val; if (val) prev.src = val; else prev.removeAttribute('src'); };
  const onFile = async inp => {
    const f = inp.files && inp.files[0]; if (!f) return;
    try { val = await readPhoto(f); } catch (e) { toast('ما قدرناش نقراو هاد الصورة'); }
    inp.value = ''; paint();
  };
  cam.addEventListener('change', () => onFile(cam));
  gal.addEventListener('change', () => onFile(gal));
  rm.addEventListener('click', () => { val = ''; paint(); });
  return { get: () => val, set: v => { val = v || ''; paint(); } };
}
const fPhoto = makePhoto('f'), ePhoto = makePhoto('e'), sPhoto = makePhoto('s');

/* ---------- views ---------- */
const thumb = (photo, name, big) => '<div class="thumb' + (big ? ' big' : '') + '">' + (photo ? '<img src="' + esc(photo) + '" alt="">' : esc((name || '؟').trim().charAt(0))) + '</div>';
const telHref = p => { const s = String(p || '').replace(/[^\d+]/g, ''); return s ? 'tel:' + s : null; };
const callBtn = (r, small) => { const h = telHref(r.phone); return h ? '<a class="btn' + (small ? ' small' : '') + '" href="' + esc(h) + '">اتصل</a>' : ''; };
const calBtn = (r, c) => c.due ? '<button type="button" class="btn small" data-act="cal" data-id="' + esc(r.id) + '">تنبيه فالتقويم</button>' : '';
const pillFor = c => '<span class="pill ' + c.state + '">' + esc(c.label) + '</span>';

function cardHTML(r, c, today) {
  const returned = r.status === 'returned';
  const eq = equipOf(r);
  const pill = returned ? (r.paid ? '<span class="pill paid">خلّص</span>' : '<span class="pill unpaid">ما خلّصش</span>') : pillFor(c);
  const meta =
    '<div><dt>' + (returned ? 'كان من' : 'بدا') + '</dt><dd>' + esc(fmtDate(r.start, today)) + '</dd></div>' +
    '<div><dt>تمن النهار</dt><dd>' + esc(money(Number(r.price))) + '</dd></div>' +
    '<div><dt>المدة</dt><dd>' + esc(dayWord(c.days)) + '</dd></div>' +
    (returned
      ? '<div><dt>رجعات نهار</dt><dd>' + esc(fmtDate(r.returnDate || today, today)) + '</dd></div>'
      : (c.due ? '<div><dt>خاصها ترجع</dt><dd>' + esc(fmtDate(c.due.date, today)) + (c.due.timed ? ' · ' + esc(r.dueTime) : '') + '</dd></div>' : '')) +
    (r.guarantee ? '<div><dt>الضمانة</dt><dd>' + esc(r.guarantee) + '</dd></div>' : '');
  let actions;
  if (confirmDel === r.id) {
    actions = '<div class="confirm"><p>واش متأكد بغيتي تمسح هاد الكراء؟</p><button type="button" class="btn warn small" data-act="del-yes" data-id="' + esc(r.id) + '">آه، مسح</button><button type="button" class="btn small" data-act="del-no">لا</button></div>';
  } else if (returning === r.id) {
    actions = '<div class="ret"><label>تاريخ الرجوع<input type="date" data-ret="1" value="' + esc(retDate) + '" min="' + esc(r.start) + '"></label><button type="button" class="btn primary" data-act="ret-ok" data-id="' + esc(r.id) + '">تأكيد الرجوع</button><button type="button" class="btn" data-act="ret-cancel">إلغاء</button></div>';
  } else if (returned) {
    actions = '<div class="acts"><button type="button" class="btn small primary" data-act="paid" data-id="' + esc(r.id) + '">' + (r.paid ? 'ألغي الخلاص' : 'سجل الخلاص') + '</button>' + callBtn(r, true) + '<button type="button" class="btn small warn" data-act="del-ask" data-id="' + esc(r.id) + '">مسح</button></div>';
  } else {
    actions = '<div class="acts"><button type="button" class="btn primary" data-act="ret-open" data-id="' + esc(r.id) + '">رجّع الأداة</button>' + callBtn(r, false) + calBtn(r, c) + '<button type="button" class="btn small warn" data-act="del-ask" data-id="' + esc(r.id) + '">مسح</button></div>';
  }
  return '<article class="card' + (c.state === 'late' ? ' late' : '') + '"><div class="c-head">' + thumb(eq && eq.photo, r.item) +
    '<div class="c-title"><h3>' + esc(r.item) + '</h3><p class="who">' + esc(r.renter) + (r.phone ? ' · <bdi dir="ltr">' + esc(r.phone) + '</bdi>' : '') + '</p></div>' + pill + '</div>' +
    '<dl class="meta">' + meta + '</dl>' +
    '<div class="c-total"><span>' + (returned ? 'المبلغ الإجمالي' : 'المبلغ حتى دابا') + '</span><strong>' + esc(money(c.total)) + '</strong></div>' + actions + '</article>';
}
function eqCardHTML(eq) {
  const by = rentedBy(eq);
  const pill = by ? '<span class="pill unpaid">مكراية عند ' + esc(by.renter) + '</span>' : '<span class="pill ok">كاينة</span>';
  const actions = confirmDelEq === eq.id
    ? '<div class="confirm"><p>واش متأكد بغيتي تمسح هاد الأداة من اللائحة؟ الكراءات القديمة غادي تبقى.</p><button type="button" class="btn warn small" data-act="eq-del-yes" data-id="' + esc(eq.id) + '">آه، مسح</button><button type="button" class="btn small" data-act="eq-del-no">لا</button></div>'
    : '<div class="acts"><button type="button" class="btn primary" data-act="eq-rent" data-id="' + esc(eq.id) + '">كريها</button><button type="button" class="btn small" data-act="eq-edit" data-id="' + esc(eq.id) + '">تعديل</button><button type="button" class="btn small warn" data-act="eq-del-ask" data-id="' + esc(eq.id) + '">مسح</button></div>';
  return '<article class="card eq"><div class="c-head">' + thumb(eq.photo, eq.name, true) + '<div class="c-title"><h3>' + esc(eq.name) + '</h3><p class="who">' + (eq.price ? esc(money(Number(eq.price))) + ' فالنهار' : 'بلا تمن') + '</p></div>' + pill + '</div>' + actions + '</article>';
}
function shCardHTML(s) {
  const q = Number(s.qty) || 0;
  const pill = q === 0 ? '<span class="pill late">نفدات</span>' : '<span class="pill ' + (q <= 3 ? 'unpaid' : 'ok') + '">باقي ' + q + '</span>';
  const actions = confirmDelSh === s.id
    ? '<div class="confirm"><p>واش تعمرات هاد السلعة؟ غادي تتحيد من لائحة الخساس.</p><button type="button" class="btn primary small" data-act="sh-del-yes" data-id="' + esc(s.id) + '">آه، تعمرات</button><button type="button" class="btn small" data-act="sh-del-no">لا</button></div>'
    : '<div class="acts"><button type="button" class="btn small" data-act="sh-edit" data-id="' + esc(s.id) + '">تعديل</button><button type="button" class="btn small primary" data-act="sh-del-ask" data-id="' + esc(s.id) + '">تعمرات</button></div>';
  return '<article class="card sh"><div class="c-head">' + thumb(s.photo, s.name, true) + '<div class="c-title"><h3>' + esc(s.name) + '</h3>' + (s.note ? '<p class="who">' + esc(s.note) + '</p>' : '') + '</div>' + pill + '</div>' + actions + '</article>';
}
const byDue = (a, b) => {
  const x = a.c.due ? a.c.due.ms : Infinity, y = b.c.due ? b.c.due.ms : Infinity;
  return x !== y ? x - y : (a.r.start < b.r.start ? -1 : 1);
};
function renderChips() {
  const eqs = data.equipment.slice().sort((a, b) => String(a.name).localeCompare(String(b.name), 'ar'));
  $('chipsWrap').hidden = !eqs.length;
  $('chips').innerHTML = eqs.map(e => '<button type="button" class="chip" data-act="pick-eq" data-id="' + esc(e.id) + '">' + thumb(e.photo, e.name) + '<span>' + esc(e.name) + '</span></button>').join('');
}

function render() {
  const now = new Date(), t = todayStr(); lastDay = t;
  $('today').textContent = headerDate();
  if (!store) return;
  if (!loaded) {
    $('alerts').innerHTML = ''; $('stats').innerHTML = '';
    $('list').innerHTML = '<p class="note full">' + (timedOut ? 'ما قدرناش نوصلو للمعلومات دابا. تأكد من الأنترنيت وعاود حل التطبيق.' : 'كنحمل المعلومات…') + '</p>';
    return;
  }
  const all = data.rentals.map(r => ({ r, c: calc(r, now) }));
  const active = all.filter(x => x.r.status !== 'returned').sort(byDue);
  const done = all.filter(x => x.r.status === 'returned').sort((a, b) => (b.r.returnDate || '') < (a.r.returnDate || '') ? -1 : 1);
  const eqs = data.equipment.slice().sort((a, b) => String(a.name).localeCompare(String(b.name), 'ar'));
  const shorts = data.shortages.slice().sort((a, b) => (Number(a.qty) || 0) - (Number(b.qty) || 0) || String(a.name).localeCompare(String(b.name), 'ar'));

  const owed = active.reduce((s, x) => s + x.c.total, 0) + done.filter(x => !x.r.paid).reduce((s, x) => s + x.c.total, 0);
  const free = eqs.filter(e => !rentedBy(e)).length;
  $('stats').innerHTML =
    '<div class="panel p-blue"><span>كراء جاري</span><strong>' + active.length + '</strong></div>' +
    '<div class="panel p-orange"><span>المبلغ المستحق</span><strong>' + esc((Math.round(owed * 100) / 100).toLocaleString('en-US')) + '<small>درهم</small></strong></div>' +
    '<div class="panel p-green"><span>أدوات كاينة</span><strong>' + free + '</strong></div>';

  const al = active.filter(x => ['late', 'hours', 'today', 'tomorrow'].indexOf(x.c.state) !== -1);
  const lateN = al.filter(x => x.c.state === 'late').length;
  $('alerts').innerHTML = al.length
    ? '<div class="alerts"><h2>تنبيهات' + (lateN ? ' · ' + lateN + ' فات وقتها' : '') + '</h2>' + al.map((x, i) =>
      '<div class="a-row' + (i === 0 ? ' first' : '') + '"><div class="a-main"><strong>' + esc(x.r.item) + '</strong><span> · ' + esc(x.r.renter) + '</span></div>' + pillFor(x.c) + callBtn(x.r, true) + '</div>').join('') + '</div>'
    : '';
  try { if (navigator.setAppBadge) { lateN ? navigator.setAppBadge(lateN) : navigator.clearAppBadge(); } } catch (e) { /* not supported */ }

  $('tab-active').textContent = 'جاري (' + active.length + ')';
  $('tab-done').textContent = 'تسالى (' + done.length + ')';
  $('tab-eq').textContent = 'الأدوات (' + eqs.length + ')';
  $('tab-short').textContent = 'الخساس (' + shorts.length + ')';
  ['active', 'done', 'eq', 'short'].forEach(k => $('tab-' + k).setAttribute('aria-selected', String(tab === k)));

  let html = '';
  if (tab === 'active') {
    const sr = savedId && data.rentals.find(r => r.id === savedId);
    if (sr) {
      const sc = calc(sr, now);
      html += '<div class="banner full"><p>تسجل الكراء.' + (sc.due ? ' بغيتي تنبيه فالتقويم نهار الرجوع؟' : '') + '</p><div class="acts">' + (sc.due ? '<button type="button" class="btn primary" data-act="cal" data-id="' + esc(sr.id) + '">زيد للتقويم</button>' : '') + '<button type="button" class="btn" data-act="dismiss-saved">دابا لا</button></div></div>';
    }
    html += active.length
      ? active.map(x => cardHTML(x.r, x.c, t)).join('')
      : '<div class="empty full"><h3>ما كاين حتى كراء جاري</h3><p>دخّل الأداة، التمن ديال النهار والكليان، وغادي نحسبو ليك الأيام والمبلغ.</p><button type="button" class="btn primary" data-act="add">زيد أول كراء</button></div>';
  } else if (tab === 'done') {
    html = done.length ? done.map(x => cardHTML(x.r, x.c, t)).join('') : '<div class="empty full"><h3>ما كاين حتى كراء سالا</h3><p>ملي ترجع شي أداة وتسجل الإرجاع، كتبان هنا.</p></div>';
  } else if (tab === 'eq') {
    html = '<div class="acts full"><button type="button" class="btn primary" data-act="eq-add">+ أداة جديدة</button></div>' +
      (eqs.length ? eqs.map(eqCardHTML).join('') : '<div class="empty full"><h3>ما كاين حتى أداة مسجلة</h3><p>الأدوات كتتسجل بوحدها ملي تكري أداة جديدة، وتقدر تزيدها هنا بالصورة والتمن.</p></div>');
  } else {
    html = '<div class="acts full"><button type="button" class="btn primary" data-act="sh-add">+ سلعة خاصها تتجاب</button>' + (shorts.length ? '<button type="button" class="btn" data-act="sh-copy">نسخ اللائحة</button>' : '') + '</div>' +
      (shorts.length ? shorts.map(shCardHTML).join('') : '<div class="empty full"><h3>لائحة الخساس خاوية</h3><p>ملي تنفد شي سلعة، دخل سميتها والعدد لي بقى منها، وصورها إلا بغيتي.</p></div>');
  }
  $('list').innerHTML = html;
  if (!$('form').hidden) renderChips();
  renderFoot();
}

function notifState() {
  if (NATIVE) { try { return NATIVE.notifState(); } catch (e) { return 'unsupported'; } }
  return ('Notification' in window) && ('serviceWorker' in navigator) ? Notification.permission : 'unsupported';
}
function renderFoot() {
  const ns = notifState();
  let acts = '';
  if (ns === 'default') acts += '<button type="button" class="btn small" data-act="notif">فعّل الإشعارات</button>';
  if (ns === 'denied' && NATIVE) acts += '<button type="button" class="btn small" data-act="notif">حل إعدادات الإشعارات</button>';
  if (deferredInstall) acts += '<button type="button" class="btn small primary" data-act="install">ثبّت التطبيق</button>';
  if (store && store.mode === 'local') acts += '<button type="button" class="btn small" data-act="backup">حفظ نسخة احتياطية</button><button type="button" class="btn small" data-act="restore">استرجاع نسخة</button>';
  if (store && store.mode === 'firebase') acts += '<button type="button" class="btn small" data-act="logout">خروج</button>';
  $('footActs').innerHTML = acts;
  let note = '';
  if (ns === 'granted') note = 'الإشعارات مفعلة: كيجيك إشعار ملي كتفوت أداة أو كيقرب وقتها.';
  else if (ns === 'denied') note = NATIVE ? 'الإشعارات مسدودة. فعّلها من إعدادات التطبيق.' : 'الإشعارات مسدودة من إعدادات المتصفح.';
  if (store && store.mode === 'firebase' && user) note += (note ? ' ' : '') + 'داخل بحساب: ' + user.email;
  if (store && store.mode === 'local') note += (note ? ' ' : '') + 'التطبيق خدام بلا حساب، والمعلومات كتبقى فهاد الجهاز وحدو.';
  $('footNote').textContent = note;
}

/* ---------- rental form ---------- */
function updateNameHint() {
  const m = findEquip($('f-item').value);
  let msg = '';
  if (m) { const by = rentedBy(m); msg = by ? 'تنبيه: هاد الأداة مكراية دابا عند ' + by.renter + '.' : 'أداة مسجلة، عمرنا التمن والصورة.'; }
  $('nameHint').textContent = msg;
}
function applyEquip(eq, fromTyping) {
  if (!fromTyping) $('f-item').value = eq.name;
  if (!fromTyping || !$('f-price').value.trim()) $('f-price').value = eq.price ? String(eq.price) : '';
  if (!fromTyping || !fPhoto.get()) fPhoto.set(eq.photo || '');
  formEquipId = eq.id; updateNameHint();
}
function showForm(which) {
  ['form', 'eform', 'sform'].forEach(id => { $(id).hidden = id !== which; });
  if (which) $(which).scrollIntoView({ block: 'start', behavior: 'smooth' });
}
function openForm(eq) {
  $('form').reset(); $('f-start').value = todayStr(); $('formErr').textContent = '';
  fPhoto.set(''); formEquipId = null; $('nameHint').textContent = '';
  if (eq) applyEquip(eq, false);
  renderChips(); showForm('form');
  setTimeout(() => $(eq ? 'f-renter' : 'f-item').focus(), 50);
}
$('f-item').addEventListener('input', () => {
  const m = findEquip($('f-item').value);
  if (m && m.id !== formEquipId) applyEquip(m, true); else if (!m) formEquipId = null;
  updateNameHint();
});
$('form').addEventListener('submit', async e => {
  e.preventDefault();
  const item = $('f-item').value.trim(), renter = $('f-renter').value.trim();
  const price = Number($('f-price').value.replace(',', '.').trim());
  const start = $('f-start').value, daysRaw = $('f-days').value.trim(), time = $('f-time').value;
  let days = daysRaw === '' ? null : Number(daysRaw);
  let err = '';
  if (!item) err = 'كتب اسم الأداة.';
  else if (!price || price <= 0) err = 'كتب تمن النهار بالدرهم.';
  else if (!renter) err = 'كتب اسم الشخص لي كرا.';
  else if (!start) err = 'اختار تاريخ الكراء.';
  else if (days !== null && (!Number.isInteger(days) || days < 0)) err = 'المدة خاصها تكون 0 (نفس النهار) أو عدد صحيح.';
  $('formErr').textContent = err;
  if (err) return;
  if (days === null && time) days = 0;
  const photo = fPhoto.get();
  let eq = (formEquipId && data.equipment.find(x => x.id === formEquipId)) || findEquip(item);
  if (!eq) {
    eq = { id: newId(), name: item, price, photo, createdAt: Date.now() };
    await store.create('equipment', eq);
  } else {
    const patch = {};
    if (photo && photo !== eq.photo) patch.photo = photo;
    if (price !== Number(eq.price)) patch.price = price;
    if (Object.keys(patch).length) await store.patch('equipment', eq.id, patch);
  }
  const r = {
    id: newId(), item, itemId: eq.id, renter, phone: $('f-phone').value.trim(), guarantee: $('f-guar').value.trim(),
    price, start, days, dueTime: days === null ? '' : time, status: 'active', returnDate: null, paid: false, createdAt: Date.now()
  };
  await store.create('rentals', r);
  showForm(null); tab = 'active'; savedId = days !== null ? r.id : null; render();
  if (days === null) toast('تسجل الكراء');
});

/* ---------- equipment and shortage forms ---------- */
function openEform(eq) {
  editingEquip = eq ? eq.id : null;
  $('eformTitle').textContent = eq ? 'تعديل الأداة' : 'أداة جديدة';
  $('e-name').value = eq ? eq.name : ''; $('e-price').value = eq && eq.price ? String(eq.price) : '';
  ePhoto.set(eq ? eq.photo : ''); $('eformErr').textContent = '';
  showForm('eform'); setTimeout(() => $('e-name').focus(), 50);
}
$('eform').addEventListener('submit', async e => {
  e.preventDefault();
  const name = $('e-name').value.trim(), price = Number($('e-price').value.replace(',', '.').trim()) || 0;
  let err = '';
  if (!name) err = 'كتب اسم الأداة.';
  else { const dup = findEquip(name); if (dup && dup.id !== editingEquip) err = 'هاد الأداة مسجلة من قبل.'; }
  $('eformErr').textContent = err; if (err) return;
  const photo = ePhoto.get();
  if (editingEquip) await store.patch('equipment', editingEquip, { name, price, photo });
  else await store.create('equipment', { id: newId(), name, price, photo, createdAt: Date.now() });
  showForm(null); editingEquip = null; tab = 'eq'; render(); toast('تسجلات الأداة');
});
function openSform(s) {
  editingSh = s ? s.id : null;
  $('sformTitle').textContent = s ? 'تعديل السلعة' : 'سلعة خاصها تتجاب';
  $('s-name').value = s ? s.name : ''; $('s-qty').value = s ? String(s.qty) : ''; $('s-note').value = s ? (s.note || '') : '';
  sPhoto.set(s ? s.photo : ''); $('sformErr').textContent = '';
  showForm('sform'); setTimeout(() => $('s-name').focus(), 50);
}
$('sform').addEventListener('submit', async e => {
  e.preventDefault();
  const name = $('s-name').value.trim(), qraw = $('s-qty').value.trim(), qty = qraw === '' ? 0 : Number(qraw);
  let err = '';
  if (!name) err = 'كتب اسم السلعة.';
  else if (!Number.isInteger(qty) || qty < 0) err = 'العدد خاصو يكون رقم صحيح (0 إلا نفدات).';
  $('sformErr').textContent = err; if (err) return;
  const body = { name, qty, note: $('s-note').value.trim(), photo: sPhoto.get() };
  const dup = data.shortages.find(x => normName(x.name) === normName(name) && x.id !== editingSh);
  if (editingSh) await store.patch('shortages', editingSh, body);
  else if (dup) { await store.patch('shortages', dup.id, Object.assign({}, body, { photo: body.photo || dup.photo || '' })); toast('هاد السلعة كانت مسجلة، تبدلات الكمية'); }
  else await store.create('shortages', Object.assign({ id: newId(), createdAt: Date.now() }, body));
  showForm(null); editingSh = null; tab = 'short'; render();
});

/* ---------- reminders ---------- */
function downloadText(filename, text, mime) {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement('a'); a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
function addToCalendar(r) {
  const di = dueInfo(r);
  if (!di) { toast('زيد المدة باش نعرفو نهار الرجوع'); return; }
  if (NATIVE) {
    const desc = 'الأداة: ' + r.item + '\nالكليان: ' + r.renter + (r.phone ? '\nالهاتف: ' + r.phone : '') + (r.guarantee ? '\nالضمانة: ' + r.guarantee : '');
    try { NATIVE.addCalendar('رجوع ' + r.item + ' - ' + r.renter, di.timed ? di.ms : di.dayStart + 9 * 36e5, desc); } catch (e) { toast('ما قدرناش نحلو التقويم'); }
    return;
  }
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
  downloadText('rjou3-' + r.id + '.ics', buildIcs(r, di, stamp), 'text/calendar');
  toast('حل الملف باش يتزاد فالتقويم');
}
function pokeSW() {
  if (NATIVE || !('serviceWorker' in navigator)) return;
  navigator.serviceWorker.ready.then(reg => { if (reg.active) reg.active.postMessage({ type: 'check' }); }).catch(() => {});
}
async function pushDue() {
  const list = activeRentals().map(r => ({ r, di: dueInfo(r) })).filter(x => x.di)
    .map(({ r, di }) => ({ id: r.id, item: r.item, renter: r.renter, dueMs: di.ms, dayStart: di.dayStart, timed: di.timed, time: r.dueTime || '' }));
  await kvSet('due', list);
  if (NATIVE) {
    try { NATIVE.setDue(JSON.stringify(list)); } catch (e) { /* bridge missing */ }
    if (notifState() === 'default' && !askedOnce) { askedOnce = true; try { NATIVE.requestNotifications(); } catch (e) { /* ignore */ } }
    return;
  }
  if (notifState() === 'granted') pokeSW();
}
async function registerPeriodic() {
  if (NATIVE) return;
  try {
    const reg = await navigator.serviceWorker.ready;
    if ('periodicSync' in reg) await reg.periodicSync.register('check-due', { minInterval: 60 * 60 * 1000 });
  } catch (e) { /* not supported or not allowed */ }
}
async function enableNotifications() {
  if (NATIVE) {
    try { if (NATIVE.notifState() === 'denied') NATIVE.openNotificationSettings(); else NATIVE.requestNotifications(); }
    catch (e) { toast('ما قدرناش نفعلو الإشعارات'); }
    return;
  }
  try {
    const p = await Notification.requestPermission();
    if (p === 'granted') { await registerPeriodic(); await pushDue(); toast('تفعلات الإشعارات'); }
  } catch (e) { toast('ما قدرناش نفعلو الإشعارات'); }
  render();
}

/* ---------- migration of data typed before accounts existed ---------- */
function legacyCount() {
  try {
    const v = JSON.parse(localStorage.getItem(LS_KEY) || 'null');
    return v ? KINDS.reduce((n, k) => n + (Array.isArray(v[k]) ? v[k].length : 0), 0) : 0;
  } catch (e) { return 0; }
}
function renderMigrate() {
  const flag = 'oussama-migrated-' + (user ? user.uid : '');
  let done = false; try { done = !!localStorage.getItem(flag); } catch (e) { /* ignore */ }
  const n = store && store.mode === 'firebase' && !done ? legacyCount() : 0;
  $('migrate').innerHTML = n
    ? '<div class="banner"><p>لقينا ' + n + ' معلومة مسجلة فهاد التيليفون قبل الحساب. بغيتي نزيدوها لحسابك؟</p><div class="acts"><button type="button" class="btn primary" data-act="migrate">آه، زيدها</button><button type="button" class="btn" data-act="migrate-skip">لا</button></div></div>'
    : '';
}
async function migrate() {
  try {
    const v = JSON.parse(localStorage.getItem(LS_KEY) || '{}');
    for (const k of KINDS) for (const o of (v[k] || [])) {
      if (o && o.id && !data[k].some(x => x.id === o.id)) await store.create(k, Object.assign({ dueTime: '' }, o));
    }
    toast('تزادو المعلومات لحسابك');
  } catch (e) { toast('ما قدرناش نزيدو المعلومات'); }
  migrateSkip();
}
function migrateSkip() { try { localStorage.setItem('oussama-migrated-' + user.uid, '1'); } catch (e) { /* ignore */ } renderMigrate(); }

/* ---------- events ---------- */
document.addEventListener('input', e => { if (e.target && e.target.dataset && e.target.dataset.ret) retDate = e.target.value; });
$('restoreFile').addEventListener('change', async () => {
  const f = $('restoreFile').files && $('restoreFile').files[0]; if (!f || !store) return;
  try {
    const v = JSON.parse(await f.text());
    if (!v || !Array.isArray(v.rentals)) throw new Error('bad');
    for (const k of KINDS) for (const o of (v[k] || [])) {
      if (!o || !o.id) continue;
      if (data[k].some(x => x.id === o.id)) await store.patch(k, o.id, o); else await store.create(k, o);
    }
    toast('تسترجعات النسخة');
  } catch (e) { toast('هاد الملف ماشي نسخة صحيحة'); }
  $('restoreFile').value = '';
});
window.__notifChanged = () => { render(); pushDue(); };
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; render(); });

document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const act = el.dataset.act, id = el.dataset.id;
  const byId = k => data[k].find(x => x.id === id);
  if (act === 'add') openForm();
  else if (act === 'cancel-form' || act === 'eq-cancel' || act === 'sh-cancel') { showForm(null); editingEquip = null; editingSh = null; }
  else if (act === 'days-set') { $('f-days').value = el.dataset.v; if (el.dataset.v === '0' && !$('f-time').value) $('f-time').value = '18:00'; }
  else if (act === 'tab') { tab = el.dataset.tab; returning = null; confirmDel = confirmDelEq = confirmDelSh = null; render(); }
  else if (act === 'pick-eq') { const eq = byId('equipment'); if (eq) applyEquip(eq, false); }
  else if (act === 'ret-open') { returning = id; confirmDel = null; retDate = todayStr(); render(); }
  else if (act === 'ret-cancel') { returning = null; render(); }
  else if (act === 'ret-ok') {
    const r = byId('rentals'); if (!r) return;
    const d = retDate || todayStr();
    if (d < r.start) { toast('تاريخ الرجوع قبل تاريخ الكراء'); return; }
    await store.patch('rentals', id, { status: 'returned', returnDate: d, paid: false });
    returning = null; tab = 'done'; render(); toast('تسجل الإرجاع');
  }
  else if (act === 'paid') { const r = byId('rentals'); if (r) await store.patch('rentals', id, { paid: !r.paid }); }
  else if (act === 'del-ask') { confirmDel = id; returning = null; render(); }
  else if (act === 'del-no') { confirmDel = null; render(); }
  else if (act === 'del-yes') { await store.remove('rentals', id); confirmDel = null; render(); toast('تمسح الكراء'); }
  else if (act === 'cal') { const r = byId('rentals'); if (r) addToCalendar(r); }
  else if (act === 'dismiss-saved') { savedId = null; render(); }
  else if (act === 'eq-add') openEform(null);
  else if (act === 'eq-edit') { const eq = byId('equipment'); if (eq) openEform(eq); }
  else if (act === 'eq-rent') { const eq = byId('equipment'); if (eq) openForm(eq); }
  else if (act === 'eq-del-ask') { confirmDelEq = id; render(); }
  else if (act === 'eq-del-no') { confirmDelEq = null; render(); }
  else if (act === 'eq-del-yes') { await store.remove('equipment', id); confirmDelEq = null; render(); toast('تمسحات الأداة'); }
  else if (act === 'sh-add') openSform(null);
  else if (act === 'sh-edit') { const s = byId('shortages'); if (s) openSform(s); }
  else if (act === 'sh-del-ask') { confirmDelSh = id; render(); }
  else if (act === 'sh-del-no') { confirmDelSh = null; render(); }
  else if (act === 'sh-del-yes') { await store.remove('shortages', id); confirmDelSh = null; render(); toast('تحيدات من الخساس'); }
  else if (act === 'sh-copy') {
    const txt = data.shortages.slice().sort((a, b) => (Number(a.qty) || 0) - (Number(b.qty) || 0)).map(s => '- ' + s.name + ' : ' + ((Number(s.qty) || 0) === 0 ? 'نفدات' : 'باقي ' + s.qty)).join('\n');
    try { await navigator.clipboard.writeText('الخساس:\n' + txt); toast('تنسخات اللائحة'); } catch (x) { toast('ما قدرناش ننسخو اللائحة'); }
  }
  else if (act === 'notif') enableNotifications();
  else if (act === 'backup') downloadText('oussama-loc-' + todayStr() + '.json', JSON.stringify(store.dump()), 'application/json');
  else if (act === 'restore') $('restoreFile').click();
  else if (act === 'migrate') migrate();
  else if (act === 'migrate-skip') migrateSkip();
  else if (act === 'install') { if (deferredInstall) { deferredInstall.prompt(); try { await deferredInstall.userChoice; } catch (x) { /* ignore */ } deferredInstall = null; render(); } }
  else if (act === 'logout') { try { await fb.signOut(fb.auth); } catch (x) { toast('ما قدرناش نخرجو'); } }
  else if (act === 'signup') authSubmit('signup');
  else if (act === 'reset') authSubmit('reset');
});

setInterval(() => { if (loaded && todayStr() !== lastDay) render(); }, 60000);
setInterval(() => { if (loaded) { render(); if (notifState() === 'granted') pokeSW(); } }, 10 * 60000);
document.addEventListener('visibilitychange', () => { if (!document.hidden && loaded) { render(); pushDue(); } });

/* ---------- session: data subscriptions ---------- */
function onData() {
  loaded = KINDS.every(k => got[k]);
  if (loaded) { clearTimeout(loadTimer); timedOut = false; pushDue(); }
  renderMigrate(); render();
}
function startSession(s) {
  endSession(); store = s;
  $('auth').hidden = true; $('main').hidden = false; $('addBtn').hidden = false;
  loadTimer = setTimeout(() => { if (!loaded) { timedOut = true; render(); } }, 10000);
  KINDS.forEach(k => {
    unsubs.push(s.subscribe(k, arr => { data[k] = arr; got[k] = true; onData(); }, () => { timedOut = true; render(); }));
  });
  render();
}
function endSession() {
  unsubs.forEach(u => { try { u(); } catch (e) { /* ignore */ } }); unsubs = [];
  KINDS.forEach(k => { data[k] = []; got[k] = false; });
  loaded = false; clearTimeout(loadTimer); store = null;
}

/* ---------- accounts (Firebase) ---------- */
const AUTH_MSG = {
  'auth/invalid-credential': 'الإيميل أو كلمة السر غالطة.', 'auth/wrong-password': 'الإيميل أو كلمة السر غالطة.',
  'auth/user-not-found': 'الإيميل أو كلمة السر غالطة.', 'auth/invalid-email': 'الإيميل ما مكتوبش مزيان.',
  'auth/email-already-in-use': 'هاد الإيميل عندو حساب من قبل، ضغط على دخول.', 'auth/weak-password': 'كلمة السر خاصها 6 حروف على الأقل.',
  'auth/missing-password': 'كتب كلمة السر.', 'auth/network-request-failed': 'ما كاينش الأنترنيت.',
  'auth/too-many-requests': 'محاولات بزاف، تسنى شوية وعاود.', 'auth/unauthorized-domain': 'هاد الموقع خاصو يتزاد فالنطاقات المسموحة ديال Firebase.'
};
async function authSubmit(kind) {
  const email = $('a-email').value.trim(), pass = $('a-pass').value;
  const msg = $('authErr'); msg.textContent = '';
  if (!fb) { msg.textContent = 'التطبيق ما واجدش، عاود حلو بالأنترنيت.'; return; }
  if (!email) { msg.textContent = 'كتب الإيميل.'; return; }
  if (kind !== 'reset' && !pass) { msg.textContent = 'كتب كلمة السر.'; return; }
  try {
    if (kind === 'login') await fb.signInWithEmailAndPassword(fb.auth, email, pass);
    else if (kind === 'signup') await fb.createUserWithEmailAndPassword(fb.auth, email, pass);
    else { await fb.sendPasswordResetEmail(fb.auth, email); msg.textContent = 'صيفطنا ليك رابط على الإيميل باش تبدل كلمة السر.'; }
  } catch (e) { msg.textContent = AUTH_MSG[e && e.code] || 'وقع مشكل، عاود جرب.'; }
}
$('authForm').addEventListener('submit', e => { e.preventDefault(); authSubmit('login'); });

async function loadFirebase() {
  const base = 'https://www.gstatic.com/firebasejs/' + FB_V + '/';
  const [app, auth, fs] = await Promise.all([import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js')]);
  const a = app.initializeApp(firebaseConfig);
  const db = fs.initializeFirestore(a, { localCache: fs.persistentLocalCache({ tabManager: fs.persistentMultipleTabManager() }) });
  return Object.assign({ auth: auth.getAuth(a), db }, auth, fs);
}
const configured = () => firebaseConfig && firebaseConfig.apiKey && !/^PASTE/.test(firebaseConfig.apiKey) && firebaseConfig.projectId && !/^PASTE/.test(firebaseConfig.projectId);

(async function boot() {
  $('today').textContent = headerDate();
  if (!NATIVE && 'serviceWorker' in navigator && location.protocol.indexOf('http') === 0) navigator.serviceWorker.register('sw.js').catch(() => {});
  if (!configured()) { startSession(localStore()); if (notifState() === 'granted') registerPeriodic(); return; }
  $('auth').hidden = false;
  try { fb = await loadFirebase(); }
  catch (e) { $('authErr').textContent = 'خاصك الأنترنيت أول مرة باش يتحل التطبيق.'; return; }
  fb.onAuthStateChanged(fb.auth, u => {
    if (u) { user = u; startSession(fbStore(u)); if (notifState() === 'granted') registerPeriodic(); }
    else { user = null; endSession(); $('main').hidden = true; $('addBtn').hidden = true; $('auth').hidden = false; }
  });
})();
