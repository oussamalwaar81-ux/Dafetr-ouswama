// Firebase web-app settings for the Oussama Loc project.
// These values are public by design. Access is protected by the Firestore rules, not by hiding them.
export const firebaseConfig = {
  apiKey: "AIzaSyAr7QGwqB9vHpH7mGteI333LZdOMmX9OhU",
  authDomain: "oussama-loc.firebaseapp.com",
  projectId: "oussama-loc",
  storageBucket: "oussama-loc.firebasestorage.app",
  messagingSenderId: "426009329694",
  appId: "1:426009329694:web:8fa7fbc3bbc256e1a26e0f"
};
